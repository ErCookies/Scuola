#include "header.h"

/*
    DESCRIZIONE FILE .csv:
    il file f.csv conterra' un elemento per riga, con i dati separati da un ';'
    ESEMPIO:
    AA000AA;Ford;Utilitaria;99.99;120;\n

    DESCRIZIONE VARIABILI:
    first, primo elemento della lista, TNodo*
    nf, nome file, char*
    f, file, FILE*
    dim, dimensione record, size_t
    str, riga letta dal file, array di LEN char
    tro, indirizzo dell'eventuale targa non univoca, TNodo*
    cor, verifica che un tipo sia corretto, bool
    car, record ausiliario in cui importare i dati , TAuto
    el, nodo della lista appena creato, TNodo*

    PSEUDOCODIFICA:
    INIZIO
        first = NULL
        apri il file nf come f (input)
        se f esiste
        allora
            leggi la prima riga dal file f in str
            mentre il file non e' finito
                spezzo str nei suoi item
                assegno il primo item a car.tar
                ricerco car.tar nella lista e ritorno il suo indirizzo in tro se trovato altrimenti NULL
                se !tro
                allora
                    assegno il secondo e terzo item a car.mod e .tipo
                    verifico che car.tipo sia corretto e ritorno true in cor se corretto, altrimenti false
                    se cor
                    allora
                        assegno il quarto item a car.prc
                        se car.prc > 0
                        allora
                            assegno l'ultimo item a car.km
                            se car.km
                        fse
                    fse
                fse
            fciclo
        altrimenti
            errore
        fse
    FINE
*/
TNodo* imp(TNodo* first, char *nf){
    FILE* f = fopen(nf, "r");
    if(f != NULL){
        size_t dim = sizeof(TNodo);
        char str[LEN];
        TNodo* tro;
        bool cor;
        fgets(str,LEN,f);
        while(!feof(f)){
            TAuto car;
            strcpy(car.tar, strtok(str,";"));
            tro = ricTar(first, car.tar);
            if(tro == NULL){
                strcpy(car.mod, strtok(NULL,";"));
                strcpy(car.tipo, strtok(NULL,";"));
                cor = contrTipo(car.tipo);
                if(cor){
                    car.prc = atof(strtok(NULL,";"));
                    if(car.prc > 0){
                        car.km = atoi(strtok(NULL,";"));
                        if(car.km > 0){
                            TNodo* el = (TNodo*)malloc(dim);
                            el->car = car;
                            if(first == NULL){
                                first = el;
                                el->next = NULL;
                            }
                            else{
                                el->next = first;
                                first = el;
                            }
                        }
                    }
                }
            }
            fgets(str,LEN,f);
        }
    }
    else
        err();
    return first;
}

TNodo* ricTar(TNodo *f, char *elTar){
    TNodo* tro = NULL;
    TNodo* p = f;
    while(p != NULL && tro == NULL){
        if(strcmp(elTar, p->car.tar) == 0)
            tro = p;
        p = p->next;
    }
    return tro;
}

bool contrTipo(char *elTipo){
    bool cor = true;
    if(strcmp(elTipo, "Utilitaria") != 0 && strcmp(elTipo, "Lusso") != 0 && strcmp(elTipo, "Comfort") != 0)
        cor  = false;

    return cor;
}

void stampa(TNodo *f){
    if(f != NULL){
        TNodo* el = f;
        while(el != NULL){
            stampaEl(el);
            el = el->next;
        }
    }
    else
        printf("Importa prima i dati\n");
}

void stampaEl(TNodo *el){
    printf("Targa: %s | ", el->car.tar);
    printf("Modello: %s | ", el->car.mod);
    printf("Tipologia: %s | ", el->car.tipo);
    printf("Prezzo al giorno: %.2f | ", el->car.prc);
    printf("Kilometraggio: %d\n", el->car.km);
}

/*
    f, primo elemento della lista, TNodo*
    ausTar, targa da cercare nella lista, array di CTAR char
    tro, indirizzo dell'eventuale record da stampare

    leggi ausTar
    ricerca ausTar nella lista e ritorna in tro il suo indirizzo o NULL
    se ausTar != NULL
    allora
        stampa il record puntato da tro
    altrimenti
        scrivi "elemento non trovato"
    fse
*/
void stampaTar(TNodo *f){
    if(f != NULL){
        char ausTar[CTAR];
        lgStr(ausTar, "Inserire targa auto interessata: ");
        TNodo* tro = ricTar(f,ausTar);
        if(tro != NULL){
            stampaEl(tro);
        }
        else
            printf("Elemento non trovato\n");
    }
    else
        printf("Importa prima i dati\n");
}

/*
    f, primo nodo della lista, TNodo*
    nf, nome file, char*
    ausTipo, tipo auto da esportare, array di CTIPO char
    fout, file su cui esportare, FILE*
    cor, verifica che ausTipo sia corretto
    dim, dimensione record da esportare, size_t
    el, nodo della lista, TNodo*

    leggi ausTipo e controlla che sia =="Utilitaria" || =="Lusso" || =="Comfort"
    leggi nf e controlla che sia !=""
    apri il file nf come fe (output)
    per ogni elemento el della lista
        se el->car.tipo == ausTipo
        allora
            scrivi el nel file
        fse
    fciclo
*/
void espTipo(TNodo *f, char* nf){
    if(f != NULL){
        char ausTipo[CTIPO];
        FILE* fout;
        bool cor;
        size_t dim = sizeof(TAuto);
        TNodo* el;
        lgStr(ausTipo, "Inserire tipo interessato: ");
        cor = contrTipo(ausTipo);
        while(!cor){
            err();
            lgStr(ausTipo, "Inserire tipo interessato: ");
            cor = contrTipo(ausTipo);
        }
        fout = fopen(nf,"w");
        el = f;
        while(el != NULL){
            if(strcmp(el->car.tipo, ausTipo) == 0)
                fwrite(&(el->car),dim,1,fout);
            el = el->next;
        }
    }
    else
        printf("Importa prima i dati\n");
}

char* myStrConcat(char *s1, char *s2){
    int d1 = length(s1);
    int d2 = length(s2);
    size_t dim = d1 + d2 + 1;
    char* strCon = (char*)malloc(dim);
    int k, j;
    for(k = 0; k<d1; k++){
       *(strCon + k) = *(s1 + k);
    }
    for(j = 0; j<d2; j++){
        *(strCon + k + j) = *(s2 + j);
    }
    *(strCon + k + j) = '\0';

    return strCon;
}

int length(char *s){
    int n = 0;
    while(*(s+n) != '\0')
        n++;
    return n;
}

/*
    leggi ausTar e controlla che sia !=""
    ricerca ausTar nella lista e ritorna in tro il suo indirizzo o NULL
    se tro != NULL
    allora
        calcolo il guadagno in guad
        scrivo "Guadagno: " guad
    altrimenti
        scrivi "elemento non trovato"
    fse

*/
void guadTar(TNodo* f){
    if(f != NULL){
        char ausTar[CTAR];
        lgStr(ausTar,"Inserire targa veicolo interessato: ");
        TNodo* p = ricTar(f,ausTar);
        if(p != NULL){
            float guad = earn(p->car);
            printf("Guadagno: %.2f\n",guad);
        }
        else
            printf("Elemento non trovato\n");
    }
    else
        printf("Importa prima i dati\n");
}

/*
    Per il calcolo del guadagno usare una funzione parametrizzata che segua le seguenti regole:
    - per il livello "utilitaria" il guadagno al km e' 0,44 euro;
    - per il livello "lusso" il guadagno al km e' 1,99 euro;
    - per il livello "confort" il guadagno al km e' 0,99 euro.
*/
float earn(TAuto el){
    float t = 0;
    if(strcmp(el.tipo,"Utilitaria") == 0)
        t = el.km * 0.44;
    else{
        if(strcmp(el.tipo,"Lusso") == 0)
            t = el.km * 1.99;
        else
            t = el.km * 0.99;
    }
    return t;
}