#include "header.h"

/*
    Francesco Cucchi 4BI

    ----------------------------------------------------------------------------------------------------------
    Esercizio: realizzare procedura per importazione dati (nome, cognome, eta)
    da un file csv ad una lista semplicemente concatenata con inserimento in testa.
    (produrre pseudo, descriz, var e traduzione in c standard)
    ----------------------------------------------------------------------------------------------------------
    Esercizio (continuazione): dalla lista di studenti caricati da file csv nello
    scorso esercizio (che quindi deve essere, se necessario, corretto), cercare e
    cancellare uno studente fornito nome e cognome.
    Produrre pseudocodice, descriz var e traduzione in cstd della procedura con relativo ambiente chiamante.
    ----------------------------------------------------------------------------------------------------------
    esercizio 1: cancellazione dalla lista degli studenti di tutti i minorenni
    esercizio 2: salvataggio della lista in un file binario
    Consegnare pseudo e traduzione i C std in One Note
    ----------------------------------------------------------------------------------------------------------

*/

int main()
{
    TNodo* first = NULL;
    int sc;
    char nf[LEN];
    do{
        menu();
        sc = lgInt(0,5,"Inserire funzione interessata: ");
        switch(sc){
            case 1:{
                first = imp(first);
                break;
            }
            case 2:{
                stampa(first);
                break;
            }
            case 3:{
                first = canc(first);
                break;
            }
            case 4:{
                cancMin(first);
                break;
            }
            case 5:{
                lgStr(nf, "Inserire nome file: ");
                espBin(first, nf);
                break;
            }
            case 0: break;
        }
    }while(sc!=0);

    return 0;
}
