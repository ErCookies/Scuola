#include "header.h"

/*
    DESCRIZIONE FILE .csv
    il file f.csv contiene un elemento per riga, con i dati separati da un ";"
    Francesco;Cucchi;16;\n

    DESCRIZIONE VARIABILI:
    first, primo elemento della lista, TNodo*
    n, numero record importati, int
    f, file .csv da cui vengono importati i dati, FILE*
    dim, dimensione del record da allocare, size_t
    str, riga letta dal file, array di LEN char
    p, elemento della lista, TNodo*

    PSEUDCODIFICA:
    INIZIO
        apri il file f.csv come f (input)
        se f esiste
        allora
            leggi la prima riga dal file f
            mentre il file non e' finito
                crea un nodo p
                se non esiste un nodo nella lista
                allora
                    imposta p come primo nodo
                    n = 1
                altrimenti
                    inserisci p nella lista come primo nodo
                    n++
                fse
                spezza str nei suoi elementi ed assegnali a p->pers.nom, .cog e .age
                leggi la riga successiva dal file
            fciclo
        altrimenti
            errore
        fse
    FINE
*/
 TNodo* imp(TNodo *first){
    FILE* f = fopen("f.csv","r");
    if(f != NULL){
        size_t dim = sizeof(TNodo); //dimensione da allocare
        char str[LEN];
        fgets(str,LEN,f);
        while(!feof(f)){
            TNodo* p = (TNodo*) malloc(dim); //dichiarazione nodo
            if(first == NULL){
                first = p;
                p->next = NULL;
            }
            else{
                p->next = first;
                first = p;
            }
            strcpy(p->pers.nom,strtok(str,";"));
            strcpy(p->pers.cog,strtok(NULL,";"));
            p->pers.age = atoi(strtok(NULL,";"));
            fgets(str,LEN,f);
        }
    }
    else
        err();

    return first;
}

void stampa(TNodo *f){
    TNodo* p = f;
    while(p != NULL){
        stampaEl(p);
        p = p->next;
    }
}

void stampaEl(TNodo *el){
    printf("Nome: %s | ", el->pers.nom);
    printf("Cognome: %s | ", el->pers.cog);
    printf("Eta': %d\n", el->pers.age);
}

/*
    se la lista esiste
    allora
        leggi ausNome e controlla che sia !=""
        leggi ausCog e controlla che sia !=""
        ricerca ausNome & ausCog nella lista e ritorna l'indirizzo del nodo in el o NULL
        se el == NULL
            scrivi "Elemento non trovato"
        altrimenti
            aus = el->next
            se el == f
            allora
                cancella el
                f = aus
            altrimenti
                cerca l'elemeto precedente ad el e mettilo in aus
                cancella el
                prec->next = aus
            fse
        fse
    altrimenti
        scrivi "la lista non esiste"
    fse
*/
TNodo* canc(TNodo *f){
    if(f != NULL){
        char ausNom[CNOM], ausCog[CNOM];
        lgStr(ausNom,"Inserire nome: ");
        lgStr(ausCog,"Inserire cognome: ");
        TNodo* el = ric(f, ausNom, ausCog);
        if(el == NULL)
            printf("Elemento non trovato\n");
        else{
            TNodo* aus = el->next;
            if(el == f){
                free(el);
                f = aus;
            }
            else{
                TNodo* prec = f;
                while(prec->next != el)
                    prec = prec->next;
                free(el);
                prec->next = aus;
            }
        }
    }
    else
        printf("La lista non esiste\n");
    return f;
}

TNodo* ric(TNodo *f, char *nome, char *cog){
    TNodo* el = NULL;
    TNodo* aus = f;
    while(el == NULL && aus != NULL){
        if(strcmp(aus->pers.nom,nome) == 0 && strcmp(aus->pers.cog,cog) == 0)
            el = aus;
        aus = aus->next;
    }
    return el;
}

/*
    PSEUDOCODIFICA
    INIZIO
        se la lista esiste
        allora
            aus = f;
            prec = NULL
            mentre aus != NULL
                |
            fciclo
        altrimenti
            scrivi "la lista non esiste"
        fse
    FINE
*/
void cancMin(TNodo *f){
    if(f != NULL){
        bool tro = false;
        TNodo* aus = f;
        TNodo* prec = NULL;
        while(aus != NULL){
            if(aus->pers.age < 18){
                if(aus == f){
                    f = aus->next;
                    free(aus);
                }
                else{
                    prec->next = aus->next;
                    free(aus);
                }
                tro = true;
            }
        }
        if(!tro)
            printf("Nessun elemento cancellato");
    }
    else
        printf("La lista non esiste\n");
}

/*
    se la lista esiste
    allora
        apri il file nf come f (output)
        aus = f
        per ogni elemento aus della lista
            scrivi aus nel file f
        fciclo
        chiudi il file
    altrimenti
        errore
    fse
*/
void espBin(TNodo *f, char* nf){
    if(f != NULL){
        FILE* fout = fopen(nf, "w");
        TNodo* aus = f;
        size_t dim = sizeof(TNodo);
        while(aus != NULL){
            fwrite(aus,dim,1,fout);
            aus = aus->next;
        }
        fclose(fout);
    }
    else
        printf("Importa prima i dati\n");
}