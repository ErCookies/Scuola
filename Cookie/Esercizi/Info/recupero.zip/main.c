#include "header.h"

/*
    Cucchi Francesco    4BI

    TESTO:
    Si supponga di dover realizzare un'applicazione che gestisca il registro scolastico di un docente per una certa disciplina.
    Ogni VALUTAZIONE e' caratterizzata dal nome e cognome dello studente, dalla classe, da una data, un tipo (orale, scritto, pratico),
    una descrizione ed un valore (da 1 a 10).

    Il registro viene salvato su un file binario avente il nome del docente concatenato alla classe ed alla disciplina insegnata
    (dati noti ad inizio esecuzione del programma). Il programma, dopo aver importato le valutazioni presenti nel file binario in una
    lista semplicemente concatenata (a), deve prevedere le seguenti funzionalita' che lavoreranno sulla lista semplicemente concatenata:

    (b) esportazione su file .csv delle valutazioni associate ad uno studente (input del nome e del cognome) con indicazione del numero
    totale delle valutazioni visualizzate e corrispondente media dei voti sull'ultima riga del file;

    (c) cancellazione della valutazione di una certa tipologia avvenuta in un giorno per un certo studente (dati forniti in input)
*/

int main()
{
    TNodo* first = NULL;
    char* nf = costrNF();
    //
    return 0;
}
