#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

///COSTANTI
#define CNOM 16
#define CCLA 4
#define CTIP 8
#define CDES 64

///STRUTTURA RECORD
typedef struct{
    int yy, mm, dd;
}Tdata;

typedef struct{
    char nome[CNOM];
    char cog[CNOM];
    char classe[CCLA];
    Tdata data;
    char tipo[CTIP];
    char desc[CDES];
    int voto;
}Tvalut;

typedef struct TNodo{
    Tvalut valut;
    struct TNodo* next;
}TNodo;

///PROCEDURE ESERCIZIO
char* costrNF();
TNodo* imp(TNodo* first, char* nf);
void esp(TNodo* first);
TNodo* canc(TNodo* first);
Tdata insData();
bool dataCorretta(Tdata d);
bool dataCmp(Tdata d1, Tdata d2);
TNodo* impOrd(TNodo* first, char* nf);

///INPUT + VARIE
int lgInt(int vmin, int vmax, char* mex);           //LEGGI INT
float lgFlt(float vmin, float vmax, char* mex);     //LEGGI FLOAT
char lgChar(char *mex);                             //LEGGI CHAR
void lgStr(char *s, char *mex);                     //LEGGI STRING
void menu();
void err();
