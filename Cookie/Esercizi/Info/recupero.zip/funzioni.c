#include "header.h"

char* costrNF(){
    char nDoc[CNOM], cDoc[CNOM], clas[CCLA], mat[CNOM];
    char* nf = (char*)malloc((CNOM * 3) + CCLA + 1);
    lgStr(nDoc, "Inserire nome docente: ");
    lgStr(cDoc, "Inserire cognome docente: ");
    lgStr(clas, "Inserire classe: ");
    lgStr(mat, "Inserire materia: ");
    nf = strcat(nf, nDoc);
    nf = strcat(nf, cDoc);
    nf = strcat(nf, clas);
    nf = strcat(nf, mat);
    nf = strcat(nf, ".bin");

    return nf;
}

/*
    apri il file nf (input)
    se nf esiste
    allora
        leggi il primo record in aus dal file nf
        mentre il file non e' finito
            istanzia un nodo a *el* runtime
            el->valut = aus
            se la lista non esiste
            allora
                associa el come primo nodo della lista
            altrimenti
                aggancia el in coda alla lista
            fse
            leggi il record aus successivo
        fciclo
        chiudi il file nf
    altrimenti
        errore
    fse
*/
TNodo* imp(TNodo* first, char* nf){
    FILE* f = fopen(nf, "r");
    if(f != NULL){
        Tvalut aus;
        size_t dim = sizeof(Tvalut);
        fread((void*)&aus, dim, 1, f);
        while(!feof(f)){
            TNodo* el = (TNodo*)malloc(sizeof(TNodo));
            el->valut = aus;
            if(first == NULL)
                first = el;
            else{
                TNodo* cur = first;
                while(cur->next != NULL)
                    cur = cur->next;
                cur->next = el;
            }
            el->next = NULL;
            fread((void*)&aus, dim, 1, f);
        }
        fclose(f);
    }
    else
        printf("Il file %s non esiste\n", nf);
}
