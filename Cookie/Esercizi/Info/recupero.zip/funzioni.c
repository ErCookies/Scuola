#include "header.h"

char* costrNF(){
    char nDoc[CNOM], cDoc[CNOM], clas[CCLA], mat[CNOM];
    char* nf = (char*)malloc((CNOM * 3) + CCLA + 1);
    lgStr(nDoc, "Inserire nome docente: ");
    lgStr(cDoc, "Inserire cognome docente: ");
    lgStr(clas, "Inserire classe: ");
    lgStr(mat, "Inserire materia: ");
    nf = strcat(nf, nDoc);
    nf = strcat(nf, cDoc);
    nf = strcat(nf, clas);
    nf = strcat(nf, mat);
    nf = strcat(nf, ".bin");

    return nf;
}

/*
    apri il file nf (input)
    se nf esiste
    allora
        leggi il primo record in aus dal file nf
        mentre il file non e' finito
            istanzia un nodo *el* a runtime
            el->valut = aus
            se la lista non esiste
            allora
                associa el come primo nodo della lista
            altrimenti
                aggancia el in coda alla lista
            fse
            leggi il record aus successivo
        fciclo
        chiudi il file nf
    altrimenti
        errore
    fse
*/
TNodo* imp(TNodo* first, char* nf){
    FILE* f = fopen(nf, "r");
    if(f != NULL){
        Tvalut aus;
        size_t dim = sizeof(Tvalut);
        fread((void*)&aus, dim, 1, f);
        while(!feof(f)){
            TNodo* el = (TNodo*)malloc(sizeof(TNodo));
            el->valut = aus;
            if(first == NULL)
                first = el;
            else{
                TNodo* cur = first;
                while(cur->next != NULL)
                    cur = cur->next;
                cur->next = el;
            }
            el->next = NULL;
            fread((void*)&aus, dim, 1, f);
        }
        fclose(f);
    }
    else
        printf("Il file %s non esiste\n", nf);

    return first;
}

/*
    leggi nomIn e controlla che sia !=""
    leggi cogIn e controlla che sia !=""
    apri il file esp.csv come f (output)
    tot = 0
    num = 0
    el = first
    mentre la lista non e' finita
        se el.valut.nome == nomIn AND el.valut.cog == cogIn
        allora
            scrivi su file csv el->valut. data, tipo, desc, voto e \n
            tot += el->valut.voto
            num++
        fse
        el = el->next
    fciclo
    se num == 0
    allora
        scrivi "nessuna valutazione esportata"
    altrimenti
        scrivi su file "Media voti: " (tot/num) ", numero valutazioni: " num
    fse
    chiudi il file
*/

void esp(TNodo* first){
    int num = 0, tot = 0;
    char nomIn[CNOM], cogIn[CNOM];
    lgStr(nomIn, "Inserire nome: ");
    lgStr(cogIn, "Inserire cognome: ");
    FILE* f = fopen("esp.csv", "w");
    TNodo* el = first;
    while(el != NULL){
        if(strcmp(el->valut.nome, nomIn) == 0 && strcmp(el->valut.cog,cogIn) == 0){
            fprintf(f,"%d;%d;%d;%s;%s;%d;\n",el->valut.data.yy, el->valut.data.mm, el->valut.data.dd, el->valut.tipo, el->valut.desc, el->valut.voto);
            tot += el->valut.voto;
            num++;
        }
        el = el->next;
    }
    if(num == 0)
        puts("Nessuna valutazione esportata");
    else{
        fprintf(f,"%d;%f;\n",num, (float)(tot/num));
    }
    fclose(f);
}

/*
    Tdata
    int yy, mm, dd;
    ---
    Tvalut;
    char nome[CNOM];
    char cog[CNOM];
    char classe[CCLA];
    Tdata data;
    char tipo[CTIP];
    char desc[CDES];
    int voto;
    (c) cancellazione della valutazione di una certa tipologia avvenuta in un giorno per un certo studente (dati forniti in input)
    |
    leggi nomIn e controlla che sia !=""
    leggi cogIn e controlla che sia !=""
    inserisci data + controlli
    leggi tipIn e controlla che sia =="orale" || =="scritto" || =="pratico"
    prec = NULL
    el = first
    ricerca l'indirizzo dell'elemento i cui dati corrispondono a quelli inseriti, tenendo traccia dell'indirizzo attuale el e del precedente prec
    se el == NULL
    allora
        scrivi "elemento non trovato"
    altrimenti
        se el == first
        allora
            first = el->next
        altrimenti
            prec->next = el->next
        fse
        libera el
    fse
    return first
*/
TNodo* canc(TNodo* first){
    char nomIn[CNOM], cogIn[CNOM], tipIn[CTIP];
    Tdata data;
    TNodo* prec;
    TNodo* el;
    bool tro = false;
    lgStr(nomIn,"Inserire nome: ");
    lgStr(cogIn,"Inserire cognome: ");
    data = insData();
    lgStr(tipIn,"Inserire tipo prova: ");
    while(strcmp(tipIn,"orale") != 0 && strcmp(tipIn,"scritto") != 0 && strcmp(tipIn,"pratico") != 0){
        err();
        lgStr(tipIn,"Inserire tipo prova: ");
    }
    prec = NULL;
    el = first;
    while(el != NULL && tro == false){
        if(dataCmp(el->valut.data, data) && strcmp(el->valut.nome, nomIn) == 0 && strcmp(el->valut.cog, cogIn) == 0 && strcmp(el->valut.tipo, tipIn) == 0)
            tro = true;
        else{
            prec = el;
            el = el->next;
        }
    }
    if(el == NULL)
        printf("Elemento non trovato\n");
    else{
        if(el == first)
            first = el->next;
        else
            prec->next = el->next;
        free(el);
    }
    return first;
}

Tdata insData(){
    Tdata d;
    d.yy = lgInt(1,INT_MAX,"Inserire anno: ");
    d.mm = lgInt(1,12,"Inserire mese: ");
    d.dd = lgInt(1,31,"Inserire giorno: ");
    while(!dataCorretta(d)){
        err();
        d.yy = lgInt(1,INT_MAX,"Inserire anno: ");
        d.mm = lgInt(1,12,"Inserire mese: ");
        d.dd = lgInt(1,31,"Inserire giorno: ");
    }
    return d;
}

bool dataCorretta(Tdata d){
    bool cor = true;
    if(false) ///controlli da inserire
        cor = false;
    return cor;
}

bool dataCmp(Tdata d1, Tdata d2){
    bool ug = false;
    if(d1.dd == d2.dd && d1.mm == d2.mm && d1.yy == d2.yy)
        ug = true;
    return ug;
}

/*
    apri il file nf (input)
    se nf esiste
    allora
        leggi il primo record in v dal file nf
        mentre il file non e' finito
            istanzia un nodo el a runtime
            el->valut = v
            se la lista non esiste
            allora
                first = el
                el->next = NULL
            altrimenti
                prec = NULL
                aus = first
                ricerca l'elemento con valut.cog alfabeticamente successivo ad el->valut.cog in aus (o NULL se non trovato) e l'elemento prcedente in prec
                se aus == first
                allora
                    first = el
                    el->next = aus
                altrimenti
                    se aus == NULL
                    allora
                        prec->next = el
                        el->next = NULL
                    altrimenti
                        prec->next = el
                        el->next = aus
                    fse
                fse
            fse
            leggi il record v successivo
        fciclo
        chiudi il file nf
    altrimenti
        scrivi "errore"
    fse
*/
TNodo* impOrd(TNodo* first, char* nf){
    FILE* f = fopen(nf, "r");
    Tvalut v;
    TNodo* el;
    TNodo* aus;
    TNodo* prec;
    bool tro;
    size_t dim = sizeof(Tvalut);
    if(f != NULL){
        fread(&v,dim,1,f);
        while(!feof(f)){
            el = (TNodo*)malloc(sizeof(TNodo));
            el->valut = v;
            if(first == NULL){
                first = el;
                el->next = NULL;
            }
            else{
                prec = NULL;
                aus = first;
                tro = false;
                while(aus!=NULL && tro == false){
                    if(strcmp(aus->valut.cog,el->valut.cog)>0)
                        tro = true;
                    else{
                        prec = aus;
                        aus = aus->next;
                    }
                }
                if(aus == first){
                    first = el;
                    el->next = aus;
                }
                else{
                    prec->next = el;
                    if(aus == NULL)
                        el->next = NULL;
                    else
                        el->next = aus;
                }
            }
            fread(&v,dim,1,f);
        }
    }
    else
        err();

    return first;
}