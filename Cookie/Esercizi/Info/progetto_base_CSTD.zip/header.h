#include <stdio.h>
#include <stdlib.h>
#include <string.h>

///COSTANTI


///STRUTTURA RECORD


///PROCEDURE ESERCIZIO


///INPUT + VARIE
int lgInt(int vmin, int vmax, char* mex);           //LEGGI INT
float lgFlt(float vmin, float vmax, char* mex);     //LEGGI FLOAT
char lgChar(char *mex);                             //LEGGI CHAR
void lgStr(char *s, char *mex);                     //LEGGI STRING
void menu();
void err();
