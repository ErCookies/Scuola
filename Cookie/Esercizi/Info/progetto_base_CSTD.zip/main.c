#include "header.h"

int main()
{
    int sc;
    do{
        menu();
        sc = lgInt(0,5,"Selezionare funzione interessata: ");
        switch(sc){
            case 1:{
                //voce
                break;
            }
            case 2:{
                //voce
                break;
            }
            case 3:{
                //voce
                break;
            }
            case 4:{
                //voce
                break;
            }
            case 5:{
                //voce
                break;
            }
            case 0:
                break;
        }
    }while(sc!=0);
    return 0;
}
