#include "header.h"

int main()
{
    int sc;
    do{
        menu();
        sc = lgInt(1,6,"Selezionare funzione interessata: ");
        switch(sc){
            case 1:{
                //voce
                break;
            }
            case 2:{
                //voce
                break;
            }
            case 3:{
                //voce
                break;
            }
            case 4:{
                //voce
                break;
            }
            case 5:{
                //voce
                break;
            }
            case 6:
                break;
        }
    }while(sc!=6);
    return 0;
}
