#include "header.h"

/*
    Francesco Cucchi    4BI

    TESTO:
    Da un file binario caricare la lista di tutti gli studenti(a). Successivamente il programma deve permettere di:
    (b) cercare e cancellare uno studente fornito nome e cognome
    (c) produrre un file csv con i dati degli studenti di una stessa classe
    (d) cancellazione dalla lista degli studenti di tutti i minorenni
    (e) trasformare l'importazione in modo tale che siano importati gli studenti in ordine alfabetico
    Produrre pseudocodice, descriz var e traduzione in cstd della procedura con relativo ambiente chiamante.

*/

int main()
{
    int sc;
    do{
        menu();
        sc = lgInt(0,5,"Selezionare funzione interessata: ");
        switch(sc){
            case 1:{
                //voce
                break;
            }
            case 2:{
                //voce
                break;
            }
            case 3:{
                //voce
                break;
            }
            case 4:{
                //voce
                break;
            }
            case 5:{
                //voce
                break;
            }
            case 0:
                break;
        }
    }while(sc!=0);
    return 0;
}
