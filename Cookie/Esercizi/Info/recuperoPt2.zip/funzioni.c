#include "header.h"

/*
    RECUPERO:
    Da un file binario caricare la lista di tutti gli studenti(a). Successivamente il programma deve permettere di:
    (b) cercare e cancellare uno studente fornito nome e cognome
    (c) produrre un file csv con i dati degli studenti di una stessa classe
    (d) cancellazione dalla lista degli studenti di tutti i minorenni
    (e) trasformare l'importazione in modo tale che siano importati gli studenti in ordine alfabetico
    Produrre pseudocodice, descriz var e traduzione in cstd della procedura con relativo ambiente chiamante.
*/

/*
    VARIABILI:
    first
    nf
    f
    el


    INIZIO
        leggi nf e controlla che sia !=""
        apri il file nf come f (input)
        se f esiste
        allora
            leggi il primo record st da f
            mentre f non e' finito
                istanzia un nodo el a runtime
                el->stud = st
                el->next = NULL
                se la lista non esiste
                allora
                    first = el
                altrimenti
                    aggancia el in coda alla lista
                fse
                leggi il record st successivo dal file f
            fciclo
            chiudi il file f
        altrimenti
            scrivi "errore"
        fse
        ritorna first
    FINE
*/
TNodo* imp(TNodo *first){
    char nf[CNOM];
    FILE *f;
    TStud st;
    TNodo *el, *aus;
    lgStr(nf, "Inserire nome file: ");
    f = fopen(nf, "r");
    if(f != NULL){
        fread(&st,sizeof(TStud),1,f);
        while(!feof(f)){
            el = (TNodo*)malloc(sizeof(TNodo));
            el->stud = st;
            el->next = NULL;
            if(first == NULL)
                first = el;
            else{
                aus = first;
                while(aus->next != NULL)
                    aus = aus->next;
                aus->next = el;
            }
            fread(&st,sizeof(TStud),1,f);
        }
        fclose(f);
    }
    else
        puts("Errore");

    return first;
}

/*
    VARIABILI:
    nomIn
    cogIn
    el
    prec
    tro

    INIZIO
        se la lista esiste
        allora
            leggi nomIn e controlla che sia !=""
            leggi cogIn e controlla che sia !=""
            ricerca l'indirizzo dell'elemento i cui dati corrispondono a quelli inseriti, tenendo traccia degli indirizzi attuale el e precedente prec
            se el == NULL
            allora
                scrivi "elemento non trovato"
            altrimenti
                se el == first
                allora
                    first = el->next
                altrimenti
                    prec->next = el->next
                fse
                libera el
            fse
        altrimenti
            scrivi "importa prima i dati"
        fse
        ritorna first
    FINE
*/
TNodo* canc(TNodo* first){
    char nomIn[CNOM], cogIn[CNOM];
    TNodo *el, *prec;
    bool tro;

    if(first != NULL){
        lgStr(nomIn, "Inserire nome studente: ");
        lgStr(cogIn, "Inserire cognome studente: ");
        prec = NULL;
        el = first;
        tro = false;
        while(el != NULL && tro == false){
            if(strcmp(nomIn, el->stud.nome) == 0 && strcmp(cogIn, el->stud.cog) == 0)
                tro = true;
            else
                el = el->next;
        }
        if(el == NULL)
            puts("Elemento non trovato");
        else{
            if(el == first)
                first = el->next;
            else
                prec->next = el->next;
            free(el);
        }
    }
    else
        puts("Importa prima i dati");

    return first;
}

//(c) produrre un file csv con i dati degli studenti di una stessa classe
/*
    VARIABILI
    clasIn
    f
    el
    tro

    INIZIO
        se la lista esiste
        allora
            leggi clasIn e controlla che sia !=""
            el = first
            apri il file f (append)
            mentre la lista non e' finita
                se el->stud.clas == clasIn
                allora
                    scrivi record el->stud su f
                    tro = true
                fse
            fciclo
            se !tro
            allora
                scrivi "Nessuno studente esportato"
            fse
            chiudi il file f
        altrimenti
            scrivi "importa prima i dati"
        fse
    FINE
*/
void esp(TNodo* first){
    char clasIn[CCLA];
    FILE *f;
    TNodo *el;
    bool tro;

    if(first != NULL){
        lgStr(clasIn, "Inserire classe: ");
        f = fopen("out.csv", "a");
        el = first;
        tro = false;
        while(el != NULL){
            if(strcmp(el->stud.clas, clasIn) == 0){
                fprintf(f, "%s;%s;%s;%d;\n",el->stud.nome, el->stud.cog, el->stud.clas, el->stud.eta);
                tro = true;
            }
            el = el->next;
        }
        if(!tro)
            puts("Nessuno studente esportato");
        fclose(f);
    }
    else
        puts("Importa prima i dati");
}