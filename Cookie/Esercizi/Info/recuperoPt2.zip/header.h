#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

///COSTANTI
#define CNOM 16
#define CCLA 4

///STRUTTURA RECORD
typedef struct{
    char nome[CNOM], cog[CNOM], clas[CCLA];
    int eta;
}TStud;

typedef struct TNodo{
    TStud stud;
    struct TNodo *next;
}TNodo;

///PROCEDURE ESERCIZIO
TNodo* imp(TNodo *first);


///INPUT + VARIE
int lgInt(int vmin, int vmax, char* mex);           //LEGGI INT
float lgFlt(float vmin, float vmax, char* mex);     //LEGGI FLOAT
char lgChar(char *mex);                             //LEGGI CHAR
void lgStr(char *s, char *mex);                     //LEGGI STRING
void menu();
void err();
