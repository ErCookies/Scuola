#include "header.h"

/*
    Francesco Cucchi 4BI

    TESTO:
    Esercizio: realizzare procedura per importazione dati (nome, cognome, eta)
    da un file csv ad una lista semplicemente concatenata con inserimento in testa.
    (produrre pseudo, descriz, var e traduzione in c standard)

    Esercizio (continuazione): dalla lista di studenti caricati da file csv nello
    scorso esercizio (che quindi deve essere, se necessario, corretto), cercare e
    cancellare uno studente fornito nome e cognome.
    Produrre pseudocodice, descriz var e traduzione in cstd della procedura con relativo ambiente chiamante.

*/

int main()
{
    TNodo* first = NULL;
    first = imp(first);
    stampa(first);
    first = canc(first);
    stampa(first);
    return 0;
}
