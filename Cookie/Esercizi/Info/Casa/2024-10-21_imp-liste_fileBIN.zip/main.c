#include "header.h"

int main()
{
    TNodo * first = NULL;
    first = imp(first);
    esp(first);
    return 0;
}
