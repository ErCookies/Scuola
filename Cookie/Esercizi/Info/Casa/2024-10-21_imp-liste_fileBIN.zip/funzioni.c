#include "header.h"
/*
    Esercizio(pseudo e traduzione in C standard)
    Realizzare il programma che prenda da un file binario prodotto.bin i dati dei prodotti di una certa categoria
    produca un file CSV con tali dati ordinati in senso crescente rispetto al codice (usare un lista semplicemente
    concatenata come struttura intermedia in cui i prodotti sono inseriti in ordine crescente di codice)

    apri il file prodotto.bin come fin (input)
    se fin esiste
    allora
        leggi un record ausIn dal file
        mentre il file non e' finito
            se catIn == ausIn->prod.cat
            allora
                se la lista non esiste
                allora
                    inserisci ausIn in testa alla lista
                altrimenti
                    ricerca l'indirizzo precedente del nodo che ha come campo prod.cod l'elemento alfabeticamente successivo a ausIn->prod.cod
                    aggancia l'elemento ausIn dopo prec
                fse
            fse
        fciclo
    altrimenti
        errore
    fse
*/

TNodo* imp(TNodo* first){
    FILE* fin = fopen("prodotto.bin","r");
    if(fin != NULL){
        char catIn[CCAT];
        lgStr(catIn,"Inserire categoria da importare: ");
        //controllo su categorie
        size_t dim = sizeof(TNodo);
        TNodo* ausIn = (TNodo*)malloc(dim);
        TNodo* ausRic = NULL;
        fread(ausIn,dim,1,fin);
        while(!feof(fin)){
            if(strcmp(catIn,ausIn->prod.cat) == 0){
                if(first == NULL){
                    first = ausIn;
                    ausIn->next = NULL;
                }
                else{
                    ausRic = ric(first, ausIn->prod.cod);
                    first = aggancio(first, ausRic, ausIn);
                }
                fread(ausIn,dim,1,fin);
            }
        }
    }
    else
        err();

    return first;
}

TNodo* ric(TNodo* first, char* elCod){
    TNodo* pos = NULL;
    TNodo* aus = first;
    TNodo* prec = NULL;
    while(aus != NULL && pos == NULL){
        if(strcmp(elCod, aus->prod.cod) < 0)
            pos = prec;
        prec = aus;
        aus = aus->next;
    }
    return pos;
}

TNodo* aggancio(TNodo* first, TNodo* prec, TNodo* el){
    if(prec == NULL){
        el->next = first;
        first = el;
    }
    else{
        if(prec->next == NULL){
            prec->next = el;
        }
        else{
            TNodo* aus;
            aus = prec->next;
            prec->next = el;
            el->next = aus;
        }
    }
    return first;
}

/*
    DESCRIZIONE FILE .csv
    Il file esp.csv conterra' un elemento per riga, con i campi, separati dal carattere ";", nel seguente ordine:
    name;cat;prc;giac;\n
*/
void esp(TNodo* first){
    FILE* f = fopen("esp.csv","w");
    TNodo* el = first;
    while(el != NULL){
        fprintf(f, "%s;%s;%f;%d;\n",el->prod.cod, el->prod.cat, el->prod.prc, el->prod.giac);
        el = el->next;
    }
}