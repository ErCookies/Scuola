#include <stdio.h>
#include <stdlib.h>
#include <string.h>

///COSTANTI
#define CNOM 16
#define CCAT 12

///STRUTTURA RECORD
typedef struct{
    char name[CNOM];
    char cat[CCAT];
    float prc;
    int giac;
}TProd;

typedef struct TNodo{
    TProd prod;
    struct TNodo* next;
}TNodo;

///PROCEDURE ESERCIZIO
TNodo* imp(TNodo* first);
TNodo* ric(TNodo* first, char* elCat);
TNodo* aggancio(TNodo* first, TNodo* prec, TNodo* el);
void esp(TNodo* first);

///INPUT + VARIE
int lgInt(int vmin, int vmax, char* mex);           //LEGGI INT
float lgFlt(float vmin, float vmax, char* mex);     //LEGGI FLOAT
char lgChar(char *mex);                             //LEGGI CHAR
void lgStr(char *s, char *mex);                     //LEGGI STRING
void menu();
void err();
