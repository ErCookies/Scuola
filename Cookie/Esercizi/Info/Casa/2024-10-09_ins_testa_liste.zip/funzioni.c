#include "header.h"

/*
    DESCRIZIONE FILE .csv
    il file f.csv contiene un elemento per riga, con i dati separati da un ";"
    Francesco;Cucchi;16;\n

    DESCRIZIONE VARIABILI:
    first, primo elemento della lista, TNodo*
    n, numero record importati, int
    f, file .csv da cui vengono importati i dati, FILE*
    dim, dimensione del record da allocare, size_t
    str, riga letta dal file, array di LEN char
    p, elemento della lista, TNodo*

    PSEUDCODIFICA:
    INIZIO
        apri il file f.csv come f (input)
        se f esiste
        allora
            leggi la prima riga dal file f
            mentre il file non e' finito
                crea un nodo p
                se non esiste un nodo nella lista
                allora
                    imposta p come primo nodo
                    n = 1
                altrimenti
                    inserisci p nella lista come primo nodo
                    n++
                fse
                spezza str nei suoi elementi ed assegnali a p->pers.nom, .cog e .age
                leggi la riga successiva dal file
            fciclo
        altrimenti
            errore
        fse
    FINE
*/
 TNodo* imp(TNodo *first, int *n){
    FILE* f = fopen("f.csv","r");
    if(f != NULL){
        size_t dim = sizeof(TNodo); //dimensione da allocare
        char str[LEN];
        fgets(str,LEN,f);
        while(!feof(f)){
            TNodo* p = (TNodo*) malloc(dim); //dichiarazione nodo
            if(first == NULL){
                first = p;
                p->next = NULL;
                *n = 1;
            }
            else{
                p->next = first;
                first = p;
                (*n)++;
            }
            strcpy(p->pers.nom,strtok(str,";"));
            strcpy(p->pers.cog,strtok(NULL,";"));
            p->pers.age = atoi(strtok(NULL,";"));
            fgets(str,LEN,f);
        }
    }
    else
        err();

    return first;
}

void stampa(TNodo *f){
    TNodo* p = f;
    while(p != NULL){
        stampaEl(p);
        p = p->next;
    }
}


void stampaEl(TNodo *el){
    printf("Nome: %s | ", el->pers.nom);
    printf("Cognome: %s | ", el->pers.cog);
    printf("Eta': %.0d\n", el->pers.age);
}
