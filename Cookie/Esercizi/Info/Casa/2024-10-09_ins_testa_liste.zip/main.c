#include "header.h"

/*
    Francesco Cucchi 4BI

    TESTO:
    Esercizio: realizzare procedura per importazione dati (nome, cognome, eta)
    da un file csv ad una lista semplicemente concatenata con inserimento in testa.
    (produrre pseudo, descriz, var e traduzione in c standard)
*/

int main()
{
    struct TNodo* first = NULL;
    int num = 0;
    first = imp(first, &num);
    stampa(first);
    return 0;
}
